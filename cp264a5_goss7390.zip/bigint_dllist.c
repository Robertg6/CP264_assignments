#include <stdio.h>
#include <stdlib.h>
#include "bigint_dllist.h"
NODE *new_node(char data) {
 NODE *p = (NODE *)malloc(sizeof(NODE));
 p->data = data;
 p->next = NULL;
 p->prev = NULL;
 return p;
}
void display_forward(NODE *np) {
 NODE *ptr = np;
 if(np == NULL){
  return;
 }
 else{
  while(np!=NULL){
   printf("%c ", np->data);
   np = np->next;
  }
 } 
}
void display_backward(NODE *np) {
 NODE *ptr = np;
 if(np == NULL){
  return;
 }
 else{
  while(np!=NULL){
   printf("%c ", np->data);
   np = np->prev;
  }
 }
}
void insert_start(NODE **startp, NODE **endp, NODE *new_np) {
 if(*startp == NULL){
  *startp = new_np;
  *endp = new_np;
 }
 else{
  (*startp)->prev = new_np;
  new_np->next = *startp;
 }
 *startp = new_np;
 (*startp)->prev = NULL;
}
void insert_end(NODE **startp, NODE **endp, NODE *new_np) {
 if(*startp == NULL) {
  *startp = new_np;
  new_np->prev = NULL;
 }
 else {
  (*endp)->next = new_np;
  new_np->prev = *endp;
 }
 *endp = new_np;
 new_np->next = NULL;
}
void delete_start(NODE **startp, NODE **endp) {
 *startp = (*startp)->next;
 (*startp)->prev = NULL;
}
void delete_end(NODE **startp, NODE **endp) {
 *endp = (*endp)->prev;
 (*endp)->next = NULL;
}
void clean(NODE **startp, NODE **endp) {
  NODE *temp;
  while (*startp != NULL){
    temp = *startp;
    *startp = (*startp)->next;
    free(temp);
  }
  *startp = NULL;
  *endp = NULL;
}
