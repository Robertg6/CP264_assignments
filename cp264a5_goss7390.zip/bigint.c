#include "bigint_dllist.h"
#include "bigint.h"
BIGINT bigint(char *p) {
  BIGINT bn = {0};
  if (p == NULL)
    return bn;
  else if (!(*p >= '0' && *p <= '9')) {// not begin with digits
    return bn;
  }
  else if (*p == '0' && *(p+1) == '\0') {// just "0"
    insert_end(&bn.start, &bn.end, new_node(*p -'0'));
    return bn;
  } 
  else {
    while (*p) {
      if (*p >= '0' && *p <= '9' ){
        insert_end(&bn.start, &bn.end, new_node(*p -'0'));
      } else {
        clean_bigint(&bn);  
        break;
      }
      p++;
    }
    return bn;
  }
}
void display_bigint(BIGINT bignumber) {
  NODE *ptr = bignumber.start;
  while ( ptr != NULL) {
    printf("%d", ptr->data);
    ptr = ptr->next;
  }
}
void clean_bigint(BIGINT *bignumberp) {
  clean(&bignumberp->start, &bignumberp->end);
}
BIGINT add(BIGINT op1, BIGINT op2) {
 BIGINT sum = bigint(NULL);

 NODE *p1 = op1.end;
 NODE *p2 = op2.end;
 int c = 0;
 int a;
 int b;
 int s;
 
 NODE *sum_startp;
 sum_startp = sum.start;
 NODE *sum_endp;
 sum_endp = sum.end;
 
 NODE **ptrptr_start;
 ptrptr_start = &sum_startp;
 NODE **ptrptr_end;
 ptrptr_end = &sum_endp;
 sum.start = (*ptrptr_start);
 sum.end = (*ptrptr_end);
 
 while(p1 != NULL || p2 != NULL){
  a = 0;
  b = 0;
  if(p1 != NULL){
   a =  (int)p1->data;
   p1 = p1->prev;
  }
  if(p2 != NULL){
   b = (int)p2->data;
   p2 = p2->prev;
  }
  //compute the sum digits and insert it at the start of the doubly linked list
  s = (a + b + c);
  if(s >= 10){
	s = (a + b + c)%10;
	c = 1;
  }
 
  else{
	  c = 0;
  }
  char char_s = s + '0';
  NODE *new = new_node(char_s);
  insert_start(&sum.start, &sum.end, new_node(s));
 }
 if(c==1){
  //insert 1 at start of the doubly linked list
  char char_c = c + '0';
  NODE *new = new_node(char_c);  
  insert_start(&sum.start, &sum.end, new_node(c));
 }
  return sum;
}
BIGINT Fibonacci(int n) {
 if (n <= 2 ) {
  return bigint("1");
 }
 else {
  BIGINT temp; 
  BIGINT f1 = bigint("1");
  BIGINT f2 = bigint("1");
  int i;
  for(i = 3; i<=n; i++){
   temp = f2;
   f2 = add(f1, f2);
   f1 = temp;
  
  }
  return f2;
 }
}