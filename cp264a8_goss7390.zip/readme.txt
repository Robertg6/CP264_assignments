Name: Robert Goss
ID: 180897390
Email: goss7390@mylaurier.ca
WorkID: cp264a8
Statement: I claim that the enclosed submission is my individual work 

Evaluation grid: [self-evaluation/total/marker-evaluation]

Q1 
1. height, balance_factor, is_avl functions     [5/5/] 
2. rotate_left, rotate_right functions          [5/5/] 
3. insert function                              [5/5/]
4. delete function                              [5/5/]

Q2
1. merge tree function                          [5/5/]
2. merge data function, stats aggregation       [5/5/] 


Test result:
Q1 output: (copy the screen output of your test run) 


Q2 output: (copy the screen output of your test run) 



Comments (if any):
